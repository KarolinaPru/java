package exceptions;

/**
 * Created by karol_000 on 21.01.2017.
 */
public class NoCurrenciesPairFoundException extends Exception {
}
