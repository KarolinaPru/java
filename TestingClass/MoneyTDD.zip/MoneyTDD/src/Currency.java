package src;

/**
 * Created by karol_000 on 21.01.2017.
 */
public final class Currency {

    public static final String PLN = "PLN";
    public static final String CHF = "CHF";

    private Currency() { }
}