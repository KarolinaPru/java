package exceptions;


/**
 * Created by karol_000 on 21.01.2017.
 */
public class NoCurrenciesPairFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8842314501414105500L;
}